package model;

/**
 * An enumeration class to represent a room type.
 */
public enum RoomType {
    SINGLE, DOUBLE;
}
